# MobileNavigation Component


## Options
No options available for this component

## Install
```
import MobileNavigation from 'components/MobileNavigation'
```

## Examples
```
<MobileNavigation />
```