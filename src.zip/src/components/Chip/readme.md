# Chip Component
a chip component

## Options
No options available for this component

## Install
```
import Chip from 'components/Chip'
```

## Examples
```
<Chip />
```