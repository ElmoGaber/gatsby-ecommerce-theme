export { default } from './QuickView';
