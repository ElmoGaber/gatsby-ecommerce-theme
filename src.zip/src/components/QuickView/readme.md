# QuickView Component


## Options
No options available for this component

## Install
```
import QuickView from 'components/QuickView'
```

## Examples
```
<QuickView />
```