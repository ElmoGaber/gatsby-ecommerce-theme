# BoxOption Component


## Options
No options available for this component

## Install
```
import BoxOption from 'components/BoxOption'
```

## Examples
```
<BoxOption />
```