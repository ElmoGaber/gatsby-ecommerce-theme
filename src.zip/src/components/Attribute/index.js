export { default } from './Attribute';
