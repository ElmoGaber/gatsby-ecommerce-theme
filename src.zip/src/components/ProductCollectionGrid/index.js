export { default } from './ProductCollectionGrid';
