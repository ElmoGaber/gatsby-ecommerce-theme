# BreadCrumbs Component
Accepts a string of array that will display in a breadcrumb styling

## Options
No options available for this component

## Install
```
import BreadCrumbs from 'components/BreadCrumbs'
```

## Examples
```
<BreadCrumbs />
```