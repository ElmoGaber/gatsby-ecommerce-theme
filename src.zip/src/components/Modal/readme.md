# Modal Component


## Options
No options available for this component

## Install
```
import Modal from 'components/Modal'
```

## Examples
```
<Modal />
```