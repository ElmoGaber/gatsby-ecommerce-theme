# Quote Component


## Options
No options available for this component

## Install
```
import Quote from 'components/Quote'
```

## Examples
```
<Quote />
```