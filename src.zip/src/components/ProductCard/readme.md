# ProductCard Component
Card component that describes the product

## Options
No options available for this component

## Install
```
import ProductCard from 'components/ProductCard'
```

## Examples
```
<ProductCard />
```