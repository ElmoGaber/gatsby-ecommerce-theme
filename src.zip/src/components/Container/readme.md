# Container Component
predefined container with various max width values

## Options
No options available for this component

## Install
```
import Container from 'components/Container'
```

## Examples
```
<Container />
```