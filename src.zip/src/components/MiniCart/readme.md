# MiniCart Component


## Options
No options available for this component

## Install
```
import MiniCart from 'components/MiniCart'
```

## Examples
```
<MiniCart />
```