# ProductCollection Component


## Options
No options available for this component

## Install
```
import ProductCollection from 'components/ProductCollection'
```

## Examples
```
<ProductCollection />
```