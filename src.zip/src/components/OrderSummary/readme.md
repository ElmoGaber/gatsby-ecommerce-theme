# OrderSummary Component


## Options
No options available for this component

## Install
```
import OrderSummary from 'components/OrderSummary'
```

## Examples
```
<OrderSummary />
```