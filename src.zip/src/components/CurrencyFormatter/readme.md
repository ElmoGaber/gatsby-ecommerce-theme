# CurrencyFormatter Component
formats a numeric value to display prices

## Options
No options available for this component

## Install
```
import CurrencyFormatter from 'components/CurrencyFormatter'
```

## Examples
```
<CurrencyFormatter />
```