export { default } from './Slider';
