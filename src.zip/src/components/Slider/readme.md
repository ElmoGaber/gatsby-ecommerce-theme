# Slider Component


## Options
No options available for this component

## Install
```
import Slider from 'components/Slider'
```

## Examples
```
<Slider />
```