# FormInputField Component


## Options
No options available for this component

## Install
```
import FormInputField from 'components/FormInputField'
```

## Examples
```
<FormInputField />
```